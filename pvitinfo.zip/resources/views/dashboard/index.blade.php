@extends('layouts/admin')

@section('name')

	Dashboard

@endsection	

@section('content')



@endsection