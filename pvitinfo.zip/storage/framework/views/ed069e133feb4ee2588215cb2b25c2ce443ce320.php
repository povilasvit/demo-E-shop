<?php if($message = Session::get('success')): ?>
<div class="strMsgContainer">
	<div class="str stripeS">		
   		<strong><?php echo e($message); ?></strong>
	</div>
</div>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
<div class="strMsgContainer">
	<div class="str stripeF">		
   		<strong><?php echo e($message); ?></strong>
	</div>	
</div>
<?php endif; ?>


<?php if($message = Session::get('max')): ?>
<div class="maxQty">
	<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert"></button>	
	<strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>


<?php if($errors->any()): ?>
<div class="alert alert-danger">
	<button type="button" class="close" data-dismiss="alert"></button>	
	Please check the form below for errors
</div>
<?php endif; ?><?php /**PATH /home/u438360037/domains/pvit.info/resources/views/includes/errors2.blade.php ENDPATH**/ ?>