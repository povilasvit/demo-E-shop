

<?php $__env->startSection('content'); ?>

	<div class="shopCateoryContainer">
		<?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($other->name == 'Shipping'): ?>
				<div class="other"><?php echo $other->content; ?></div>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div> <!-- shopCateoryContainer -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageScript'); ?>

	<script>
		    document.addEventListener("DOMContentLoaded", function(event) { 
		        var scrollpos = localStorage.getItem('scrollpos');
		        if (scrollpos) window.scrollTo(0, scrollpos);
		    });

		    window.onbeforeunload = function(e) {
		        localStorage.setItem('scrollpos', window.scrollY);
		    };
	</script>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Linvity\resources\views/front/shipping.blade.php ENDPATH**/ ?>