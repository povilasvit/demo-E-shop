<!DOCTYPE html>
<html>
<head>
<title>pvit.info</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">



<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" integrity="sha512-q3eWabyZPc1XTCmF+8/LuE1ozpg5xxn7iO89yfSOd5/oKvyqLngoNGsx8jq92Y8eXJ/IRxQbEC+FGSYxtk2oiw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- Google Icons -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Alegreya&display=swap" rel="stylesheet">
<!-- Swipper.js -->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
<!-- Main CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">


</head>
<body>
	<main>
		<div class="header">
			<nav>
				<div class="navi">
					<a class="nav navActive">E-Parduotuvė</a>
					<a class="nav navActive">Kontaktai</a>
					<?php if(Auth::user()): ?>
						<a href="<?php echo e(route('orders.index')); ?>" class="navAdmin nav navActive">Admin</a>
					<?php endif; ?>
					<?php if(Cart::count() > 0): ?>
						<a href="<?php echo e(route('cart')); ?>" class="nav navActive naviIcon">
							<div class="navIcon"><img src="<?php echo e(asset('images/icons/icons8-shopping-bag-48.png')); ?>"></div>
							<span class="navBagItemsCount"><?php echo e(Cart::count()); ?></span>
						</a>
					<?php else: ?>
						<a href="" class="nav navActive naviIcon" style="display:none">
							<div class="navIcon"><img src="<?php echo e(asset('images/icons/icons8-shopping-bag-48.png')); ?>"></div>
							<span class="navBagItemsCount"><?php echo e(Cart::count()); ?></span>
						</a>
					<?php endif; ?>	
				</div>
				<div class="hamburgerNav">
					<div class="hamburger">
						<span class="line lineA"></span>
						<span class="line lineB"></span>
						<span class="line lineC"></span>
					</div>
					<div class="hamburgerMenu">
						<ul>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="menuItem"><a href="<?php echo e(route('webcategory', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>	
				</div>
			</nav> 
			<div class="mainCarousel">
				<img class="imgMainCarousel activeCarousel" loading="lazy" src="<?php echo e(asset('images/main_carousel/jewellery-g87695a112_640.jpg')); ?>">
				<img class="imgMainCarousel" loading="lazy" src="<?php echo e(asset('images/main_carousel/buddhism-g8d392a75f_640.jpg')); ?>">
				<img class="imgMainCarousel" loading="lazy" src="<?php echo e(asset('images/main_carousel/beads-g524005b2a_1280.jpg')); ?>">
				<img class="imgMainCarousel" loading="lazy" src="<?php echo e(asset('images/main_carousel/glass-g05d61d989_1920.jpg')); ?>">
				<img class="imgMainCarousel" loading="lazy" src="<?php echo e(asset('images/main_carousel/beads-g9c5b635ec_1280.jpg')); ?>">
			</div>
			<div class="navText">
				<div class="navTextH">Rankų darbo papuošalai</div>			
				<div class="goToShop"><p>Eiti į Parduotuvę</p>
					<div class="goToShopB"><i class="downArrow fa-solid fa-angles-down"></i></div>
				</div>			
							
			</div>
		</div>
		
		<?php echo $__env->yieldContent('content'); ?> 


		<div class="contactContainer">
			<div class="contactText">Parašykite Mums</div>
			<form action="<?php echo e(route('contact.us.store')); ?>" method="POST" class="contactForm" id="coctactUsForm">
				<?php echo csrf_field(); ?>
				<div class="messageInput">
					<label for="name">Vardas</label>
					<input class="messageIt" type="text" id="contactUsName" name="name" value="<?php echo e(old('name')); ?>">
					<div id="contactNameError" class="errorContact"></div>
					<div id="contactNameValid" class="errorContact"></div>
				</div>
				<div class="messageInput">
					<label for="mail">El. paštas</label>
					<input class="messageIt" type="text" id="contactUsMail" name="email" value="<?php echo e(old('email')); ?>">
					<div id="contactMailError" class="errorContact"></div>
					<div id="contactMailValid" class="errorContact"></div>
				</div>
				<div class="messageInput">
					<label for="message">Jūsų žinutė</label>
					<textarea name="message" id="contactUsMessage"><?php echo e(old('message')); ?></textarea>
					<div id="contactMessageError" class="errorContact"></div>
				</div>
				<div class="contactBtn">
					<button id="contactBtnSend">Siųsti  <i class="fa-regular fa-paper-plane"></i></button>				
				</div>	
			</form>
		</div> <!-- contactContainer -->
		<?php if(Cart::count() > 0): ?>
			<div class="shoppingCart">
				<a href="<?php echo e(route('cart')); ?>" class="innerCircle">
					<img src="/images/icons/icons8-shopping-bag-48().png">
				</a>
				<span class="shoppingCartCount"><?php echo e(Cart::count()); ?></span>
			</div> 
		<?php else: ?> 
			<div class="shoppingCart" style="visibility:hidden">
				<a href="" class="innerCircle">
					<img src="/images/icons/icons8-shopping-bag-48().png">
				</a>
				<span class="shoppingCartCount"><?php echo e(Cart::count()); ?></span>
			</div> 
		<?php endif; ?>

		<footer>
			<div class="footerPrimary">
				<div class="section">
					<div><h3>Asortimentas</h3></div>
						<div><a href="<?php echo e(route('allProducts')); ?>">Visos Prekės</a></div>

						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div><a href="<?php echo e(route('webcategory', $category->id)); ?>"><?php echo e($category->name); ?></a></div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="section2">
					<div><h3>Nuorodos</h3></div>
					<div><a href="<?php echo e(route('shipping')); ?>">Prekių Pristatymas</a></div>
					<div><a href="<?php echo e(route('return_and_replacement')); ?>">Prekių Grąžinimas</a></div>
					<div><a href="<?php echo e(route('privacy')); ?>">Prekių Pristatymas</a></div>
				</div>
				<div class="section3">
					<div><h3>Kontaktai</h3></div>
					<div><a href=""><i class="fas fa-phone"></i> +37068955555</a></div>
					<div><a href=""><i class="fas fa-envelope-square"></i> povilasvitkauskass@gmail.com</a></div>
					<div><a href=""><i class="fab fa-facebook-f"></i> Pvit.info Facebook</a></div>
					<div><a href=""><i class="fab fa-instagram"></i> Pvit.info Instagramk</a></div>
				</div>
			</div>
		</footer>


	</main>
	<!-- Swiper JS -->
	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script
	<!-- Initialize Swiper -->
	<script>
	  var swiper = new Swiper(".mySwiper", {
	    slidesPerView: 1,
	    spaceBetween: 30,
	    loop: true,
	    pagination: {
	      el: ".swiper-pagination",
	      clickable: true,
	    },
	    navigation: {
	      nextEl: ".swiper-button-next",
	      prevEl: ".swiper-button-prev",
	    },
	  });
	</script>
	<script src="<?php echo e(asset('js/main.js')); ?>"></script>
	<?php echo $__env->yieldContent('pageScript'); ?>
</body>
</html><?php /**PATH /home/u438360037/domains/pvit.info/resources/views/layouts/front.blade.php ENDPATH**/ ?>