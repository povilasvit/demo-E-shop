

<?php $__env->startSection('content'); ?>

	<div class="shopCateoryContainer">
		<?php echo $__env->make('includes.errors2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<h3 class="categoryHeader">Pasirinkite Grupę</h3>	
		<div class="categoryWrapper categoryApear">
			<a href="<?php echo e(route('allProducts')); ?>" class="mainPageCategory">
				<div class="categoryImg" ><img loading="lazy" src="images/categories/galvos-lankeliai-600x600.jpg"></div>
				<div class="categoryText"><h3>Visos Prekės</h3></div>					
			</a>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e(route('webcategory', $category->id)); ?>" class="mainPageCategory">
					<div class="categoryImg"><img loading="lazy" src="images/categories/<?php echo e($category->path); ?>"></div>
					<div class="categoryText"><h3><?php echo e($category->name); ?></h3></div>
				</a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div> <!-- categoryWrapper -->
	</div> <!-- shopCateoryContainer -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageScript'); ?>

	<script src="<?php echo e(asset('js/categories.js')); ?>"></script>
	<script>
		    document.addEventListener("DOMContentLoaded", function(event) { 
		        var scrollpos = localStorage.getItem('scrollpos');
		        if (scrollpos) window.scrollTo(0, scrollpos);
		    });

		    window.onbeforeunload = function(e) {
		        localStorage.setItem('scrollpos', window.scrollY);
		    };
	</script>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/front/index.blade.php ENDPATH**/ ?>