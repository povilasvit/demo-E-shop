

<?php $__env->startSection('name'); ?>

	Products

<?php $__env->stopSection(); ?>	


<?php $__env->startSection('content'); ?>

<div class="mb-3">
	<a class="badge badge-secondary" href="<?php echo e(route('products.index')); ?>">All</a>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a class="badge badge-secondary" href="<?php echo e(route('products.category', $category->id)); ?>"><?php echo e($category->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
</div>

<?php if(count($products)>0): ?>

	<table style="font-size: 0.75rem;" class="table table-hover">

			<thead>
				<tr>
					<th scope="col">#</th>
					<th >1st picture</th>					
					<th >Category</th>
					<th >Name</th>
					<th >Product in Stock</th>
					<th >Price (Eur)</th>
					<th >Discount</th>
					<th >Last Price</th>
					<th ></th>	
					<th ></th>	
					<th ></th>	
				</tr>
			</thead>
			<tbody>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th class="align-middle"><?php echo e($product->id); ?></th>
					<td class="align-middle"><img style="height: 10vh;" class="img-thumbnail" src="/images/products/<?php echo e($product->path); ?>"></td>				
					<td class="align-middle"><?php echo e($product->category->name); ?></td>
					<td class="align-middle"><?php echo e($product->name); ?></td>
					<td class="align-middle"><?php echo e($product->inStock); ?></td>
					<td class="align-middle"><?php echo e($product->price); ?></td>
					<td class="align-middle"><?php echo e($product->discount->name); ?></td>			
					<td class="align-middle"><?php echo e($product->lastPrice); ?></td>
					<td class="align-middle"><a href="<?php echo e(route('singleProduct', $product->slug)); ?>" type="button" class="btn btn-info btn-sm">View</ba></td>
					<td class="align-middle"><a href="<?php echo e(route('products.edit', $product->slug)); ?>" type="button" class="btn btn-success btn-sm">Edit</a></td>
					<td class="align-middle">
						<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">Delete</button>											
					</td>
				</tr>
			</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Are you sure you want to delete It?</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Go Back</button>
	        <form action="<?php echo e(route('products.destroy', $product->slug)); ?>" method="POST">
	        	<?php echo csrf_field(); ?>
	        	<input type="hidden" name="_method" value="DELETE">
	        	<button type="submit" class="btn btn-danger">Yes, Delete</button>
	        </form>	
	      </div>
	    </div>
	  </div>
	</div>
			<?php echo e($products->links()); ?>


 <?php else: ?> 

		<h1 class="text-center">No Products created</h1>

	

	<?php endif; ?>
		




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/products/index.blade.php ENDPATH**/ ?>