

<?php $__env->startSection('name'); ?>

	Categories Update

<?php $__env->stopSection(); ?>	

<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row d-flex bd-highlight mb-3">
		<div class="col-4 mr-auto p-2 bd-highlight">

			<form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="_method" value="PUT">	
				<div class="form-group">
					<label for="name">Category</label>
					<input type="text" name="name" id="name" class="form-control" value="<?php echo e($category->name); ?>">
				</div>
				<div class="form-group">
					<label for="file">Category Image</label><br>
					<img class="img-thumbnail mb-3" src="/images/categories/<?php echo e($category->path); ?>">
					<input type="file" name="file">
				</div>	
				<div class="form-group">
					<button type="submit" class="btn btn-success form-control">Update Category</button>
				</div>

			</form>

		</div>

		</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/categories/edit.blade.php ENDPATH**/ ?>