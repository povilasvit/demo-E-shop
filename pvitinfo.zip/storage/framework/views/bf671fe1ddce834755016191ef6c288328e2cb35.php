;

<?php $__env->startSection('name'); ?>

	Create Product

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<div class="col-9 ml-5">
		<form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="category">Category</label>
				<select name="category_id" id="category_id" class="form-control col-6">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($category->id); ?>">
							<?php echo e($category->name); ?>

						</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label for="discount">Discount</label>
				<select name="discount_id" id="discount_id" class="form-control col-6">
					<?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($discount->id); ?>">
							<?php echo e($discount->name); ?>

						</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label for="name">Product Name</label>
				<input type="text" name="name" id="name" class="form-control col-6" value="<?php echo e(old('name')); ?>" placeholder="Enter Product Name">
			</div>
			<div class="form-group">
				<label for="inStock">Products in Stock</label>
				<input type="text" name="inStock" id="inStock" class="form-control col-6" value="<?php echo e(old('inStock')); ?>" placeholder="Enter Product Quantity">
			</div>
			<div class="form-group">
				<label for="price">Product Price</label>
				<input type="text" name="price" id="price" class="form-control col-6" value="<?php echo e(old('price')); ?>" placeholder="Enter Product Price">
			</div>			
			<div class="form-group">
				<label for="description">Product Description</label>
				<textarea name="description" class="form-control" cols="5" rows="5"><?php echo e(old('description')); ?></textarea>
			</div>
			<div class="form-group">
				<input id="content" type="hidden" name="content" value="<?php echo e(old('content')); ?>">
				<trix-editor input="content"></trix-editor>
			</div>
			<div class="form-group">
				<label for="file">1st Image</label><br>
				<input type="file" name="file">
			</div>
			<div class="form-group">
				<label for="file">2nd Image</label><br>
				<input type="file" name="file2">
			</div>
			<div class="form-group">
				<label for="file">3rd Image</label><br>
				<input type="file" name="file3">
			</div>				
			<div class="form-group">
				<button type="submit" class="btn btn-info form-control col-6">Add Product</button>
			</div>
		</form>		
	</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('trixScript'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.4/trix.js" integrity="sha512-zEL66hBfEMpJUz7lHU3mGoOg12801oJbAfye4mqHxAbI0TTyTePOOb2GFBCsyrKI05UftK2yR5qqfSh+tDRr4Q==" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/products/create_product.blade.php ENDPATH**/ ?>