

<?php $__env->startSection('content'); ?>
		<?php if(Cart::content()->count() > 0): ?>

		<div class="shopCateoryContainer">
			<form 
				action="<?php echo e(route('charge')); ?>" 
				method="post"
				role="form"
				class="require-validation paymentFormValdation"
				data-cc-on-file="false"
				data-stripe-publishable-key="<?php echo e(env('STRIPE_KEY')); ?>"
				id="payment-form">
				<?php echo csrf_field(); ?>
					<div class="checkoutWrapper">
						<div class="basket">
							<h4>Jūsų Pirkinių Krepšelis</h4>
							<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="basketItem">
									<a href="<?php echo e(route('cartDelete', $product->rowId)); ?>"><i class="fas fa-times"></i></a>
									<div class="productPhoto"><img src='/images/products/<?php echo e($product->options->image); ?>'></div>
									<div class="productNameCheckout"><?php echo e($product->name); ?></div>
									<div class="productQty">
										<div class="maxQty"><?php echo e($product->options->inStock); ?></div>
										<div class="maxQtyError">Maks. <?php echo e($product->options->inStock); ?> vnt.</div>
										<div class="prQty">
											<a href="<?php echo e(route('cartDsc', ['id' => $product->rowId, 'qty' => $product->qty])); ?>"><i class="fas fa-minus"></i></a>
											<div class="cartItemQty"><?php echo e($product->qty); ?></div>
											<a href="<?php echo e(route('cartIncr', ['id' => $product->rowId, 'qty' => $product->qty])); ?>" class="cartIncr"><i class="fas fa-plus"></i></a>					
										</div>
									</div>
									<div class="productCheckoutPrice"><?php echo e($product->price); ?> Eur</div>
									<div class="productTotalPrice"><?php echo e($product->price * $product->qty); ?> Eur</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
							<div class="total">
								<input id="cartPrice" type="hidden" value="<?php echo e(number_format(Cart::initial(), 0)); ?>">				
								<input id="shippingPrice" type="hidden" value="5">				
								<input id="totalPrice" type="hidden" value="">				
								<div>Pristatymas: <span class="deliveryPrice">5 Eur</span></div>						
								<div>Viso: <span class="lastPrice"><?php echo e(number_format(Cart::initial(), 0)); ?> Eur</span></div>								
							</div>
						</div>
						<div class="addressSection">
							<div class="address">
							<h3>Pristatymas</h3>
								<div class="addressForm">
									<div class="formInput formDrop">
										<label for="delivery" class="addressInputLabel"><span class="inputName"><i class="fa-regular fa-circle-right"></i> Pristatymo būdas</span></label>
										<select  name="delivery_id" id="delivery_id" class="formSelect">
											<?php $__currentLoopData = $delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dlvr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($dlvr->id); ?> <?php echo e($dlvr->price); ?>">
													<?php echo e($dlvr->name); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>		
									</div>
									<div class="formInput">
										<label for="name" class="addressInputLabel"><span class="inputName"><i class="fa-regular fa-user"></i> Vardas Pavardė</span></label>
										<input id="checkoutName"  type="text" name="name">
										<div id="checkoutNameError" class="errorCart errorCartFont"></div>
										<div id="checkoutNameValid" class="errorCart"></div>
									</div>
									<div class="formInputDuoble">
										<div class="formInput">
											<label for="phone" class="addressInputLabel"><span class="inputName"><i class="fas fa-mobile-alt"></i> Telefonas</span></label>
											<input id="checkoutPhone" type="text" name="phone">							
											<div id="checkoutPhoneError" class="errorCart errorCartFont"></div>
											<div id="checkoutPhoneValid" class="errorCart"></div>
										</div>
										<div class="formInput">
											<label for="email" class="addressInputLabel"><span class="inputName"><i class="far fa-envelope"></i> E-paštas</span></label>
											<input id="checkoutMail" type="text" name="email">
											<div id="checkoutMailError" class="errorCart errorCartFont"></div>
											<div id="checkoutMailValid" class="errorCart"></div>
										</div>
									</div>
									<div class="formInputDuoble">
										<div class="formInput">
											<label for="address" class="addressInputLabel"><span class="inputName"><i class="fas fa-map-marker-alt"></i> Adresas</span></label>
											<input id="checkoutAddress" type="text" name="address">
											<div id="checkoutAddressError" class="errorCart errorCartFont"></div>
											<div id="checkoutAddressValid" class="errorCart"></div>
										</div>
										<div class="formInput">
											<label for="address2" class="addressInputLabel"><span class="inputName"><i class="fas fa-map-marker-alt"></i>  2-as Adresas</span></label>
											<input id="address2" type="text" name="address2">
										</div>
									</div>
									<div class="formInput">
										<label for="dsc" class="addressInputLabel"><span class="inputName"><i class="far fa-edit"></i>  Žinutė</span></label>
										<textarea id="note" name="note"></textarea>
									</div>
									<div class="formBtn">
										<a href="<?php echo e(route('frontHome')); ?>" class="btnAddress btnAddressBack"><i class="fas fa-chevron-left"></i> Grįžti į El.Parduotuvę</a>								
										<a class="btnAddress btnAddressForward" id="btnAddressForwardBtn">Toliau (1/2) <i class="fas fa-chevron-right"></i></a>								
									</div>								
								</div>
							</div>
						<div class="payment">
							<h3>Mokėjimo informacija</h3>
							<div class="paymentForm">
									<div class="formInput">
										<label for="cartNumber" class="addressInputLabel">
											<i class="fa-regular fa-credit-card"></i>
											<span class="inputName"> Kortelės Numeris</span>
										</label>
										<input id="cartNumber" type="text" name="cartNumber" class="card-number" placeholder="">
										<div id="cartNumberError" class="errorCart errorCartFont"></div>
									</div>
									<div class="formInput">
										<label for="address" class="addressInputLabel">
											<i class="fa-regular fa-user"></i>
											<span class="inputName"> Kortelės Savininko Vardas Pavardė</span>
										</label>
										<input id="ownerName" type="text" name="ownerName" placeholder="">
										<div id="cartOwnerError" class="errorCart errorCartFont"></div>
									</div>
									<div class="formInputTriple">
										<div class="formInput">
											<label for="address" class="addressInputLabel"><span class="inputName"> Kortelės Galiojimo Laikas</span></label>
											<div class="formInputCard">										
												<input id="cartExpMonth" type="text" name="cardMonth" class="card-expiry-month" placeholder="pvz.: 12">
												<div id="expMonth" class="errorCart errorCartFont"></div>
												<input id="cartExpYear" type="text" name="cardYear" class="card-expiry-year" placeholder="pvz.: 2025">
												<div id="expYear" class="errorCart errorCartFont"></div>
											</div>
										</div>
										<div class="formInput">
											<label for="cvc" class="addressInputLabel"><span class="inputName"> Saugos Skaičius</span></label>
											<input id="cartCvc" type="text" name="cvc" class="card-cvc" placeholder="">
											<div id="cartCvcError" class="errorCart errorCartFont"></div>
										</div>
									</div>
									<div class="formBtn">
										<a class="btnAddress btnAddressBack btnPaymentBack"><i class="fas fa-chevron-left"> </i>Atgal</a>								
										<button class="btnAddress btnAddressForward btnBuy">Pirkti<i class="fas fa-chevron-right"></i></button>	
									</div>								
								</div>
							</div>
						</div>


					</div> <!-- checkoutWrapper -->

			</form>	
		</div> <!-- shopCateoryContainer -->
		<?php else: ?>
				<h3 class="emptybasketH3">Jūsų Pirkinių Krepšelis Tuščias</h3>
		<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageScript'); ?>

	<script src='js/checkout.js'></script>
	<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
	<script type="text/javascript">
	      $(function() {
	    var $form = $(".require-validation");
	    $('form.require-validation').bind('submit', function(e) {
	        var $form = $(".require-validation"),
	            inputSelector = ['input[type=email]', 'input[type=password]',
	                'input[type=text]', 'input[type=file]',
	                'textarea'
	            ].join(', '),
	            $inputs = $form.find('.required').find(inputSelector),
	            $errorMessage = $form.find('div.error'),
	            valid = true;
	        $errorMessage.addClass('hide');
	        $('.has-error').removeClass('has-error');
	        $inputs.each(function(i, el) {
	            var $input = $(el);
	            if ($input.val() === '') {
	                $input.parent().addClass('has-error');
	                $errorMessage.removeClass('hide');
	                e.preventDefault();
	            }
	        });
	        if (!$form.data('cc-on-file')) {
	            e.preventDefault();
	            Stripe.setPublishableKey($form.data('stripe-publishable-key'));
	            Stripe.createToken({
	                number: $('.card-number').val(),
	                cvc: $('.card-cvc').val(),
	                exp_month: $('.card-expiry-month').val(),
	                exp_year: $('.card-expiry-year').val()
	            }, stripeResponseHandler);
	        }
	    });
	    function stripeResponseHandler(status, response) {
	        if (response.error) {
	            $('.error')
	                .removeClass('hide')
	                .find('.alert')
	                .text(response.error.message);
	        } else {
	            /* token contains id, last4, and card type */
	            var token = response['id'];
	            $form.find('input[type=text]').empty();
	            $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
	            $form.get(0).submit();
	        }
	    }
	});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u438360037/domains/pvit.info/resources/views/front/cart.blade.php ENDPATH**/ ?>