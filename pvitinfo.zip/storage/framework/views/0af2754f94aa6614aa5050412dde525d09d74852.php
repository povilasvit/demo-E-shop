<h2><?php echo e($data->name); ?></h2> 
<br>
    
<strong>User details: </strong><br>
<strong>Name: </strong><?php echo e($data->name); ?> <br>
<strong>Email: </strong><?php echo e($data->email); ?> <br>
<strong>Message: </strong><?php echo e($data->message); ?> <br><br>
  
<?php /**PATH C:\xampp\htdocs\Linvity\resources\views/emails/contact.blade.php ENDPATH**/ ?>