

<?php $__env->startSection('content'); ?>


	
		<div class="shopCateoryContainer">
			<div class="productSingleWrapper">

				<div class="productSingle">
					<div class="productCarousel swiper mySwiper">
					  <div class="swiper-wrapper">
						    <div class="swiper-slide"><img class="singleProductCarousel singleCarouselLeftImg swiper-slide" src="/images/products/<?php echo e($product->path); ?>"></div>
						    <div class="swiper-slide"><img class="singleProductCarousel singleCarouselActiveImg swiper-slide" src="/images/products/<?php echo e($product->path2); ?>"></div>
						    <div class="swiper-slide"><img class="singleProductCarousel singleCarouselRighrImg swiper-slide" src="/images/products/<?php echo e($product->path3); ?>"></div>
						   </div>
					  <div class="swiper-button-next productCarouselArrow right"></div>
					  <div class="swiper-button-prev productCarouselArrow left"></div>
					  <div class="singleCarouselDots swiper-pagination dots"></div>
					</div>
					
					<div class="productInfo">
						<div class="productInfoSectionName">
							<h3><?php echo e($product->category->name); ?></h3>
							<h2><?php echo e($product->name); ?></h2>
						</div>
						<div class="productInfoSectionDsc">							
							<div class="dsc1"><?php echo e($product->description); ?></div>
							<div class="dsc2"><?php echo $product->content; ?></div>
						</div>
						<?php if($product->discount->value !== 0): ?>
							<div class="productPrice singlePrice">
								<span class="higherPrice"><?php echo e($product->price); ?></span>
								<span class="higherPrice2 higherPrice2Single">-</span> <?php echo e($product->lastPrice); ?>

								<span class="eur">Eur</span>
							</div>
						<?php else: ?>
							<div class="productPrice singlePrice">								
								<?php echo e($product->lastPrice); ?>

								<span class="eur">Eur</span>
							</div>
						<?php endif; ?>
						<div class="singlePrBtn">
							<form action="<?php echo e(route('cartAdd')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<input type="hidden" name="qty" value='1'>
								<input type="hidden" name="product_id" value='<?php echo e($product->id); ?>'>
								<button class="btnAddToBasket singleProductBtn">
									<i class="fasIcon fas fa-shopping-basket"></i>
									<p class="btnAddToBasketPar">Pridėti į Krepšelį</p>
								</button>								
							</form>
							<a href="<?php echo e(route('frontHome')); ?>" class="btnProductMore singleMoreBtn">
								<i class="fa-solid fa-chevron-left"></i>
								<p class="singleMoreBtnBackP"> Grįžti į Parduotuvę</p>
							</a>							
						</div>	

					</div>	
				</div>
			</div> <!-- productSingleWrapper -->


		</div> <!-- shopCateoryContainer -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageScript'); ?>

	<script src="<?php echo e(asset('js/single_product.js')); ?>"></script>
	<script>
	    document.addEventListener("DOMContentLoaded", function(event) { 
	        var scrollpos = localStorage.getItem('scrollpos');
	        if (scrollpos) window.scrollTo(0, scrollpos);
	    });

	    window.onbeforeunload = function(e) {
	        localStorage.setItem('scrollpos', window.scrollY);
	    };
	</script>
	
<?php $__env->stopSection(); ?>


 





<?php echo $__env->make('layouts/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/front/singleProduct.blade.php ENDPATH**/ ?>