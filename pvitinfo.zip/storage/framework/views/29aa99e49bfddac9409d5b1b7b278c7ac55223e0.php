

<?php $__env->startSection('content'); ?>

		<div class="shopCateoryContainer">
			<h3 class="categoryHeader"></h3>
				<div class="productsWrapper">
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($product->inStock > 0): ?>
							<?php if($product->discount->value !== 0): ?>
								<div class="products">
									<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="productImg" ><img src="/images/products/<?php echo e($product->path); ?>"></a>
									<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="productText"><h3><?php echo e($product->name); ?></h3></a>
									<div class="productPrice">
										<span class="higherPrice"><?php echo e($product->price); ?></span>
										<span class="higherPrice2">-</span> <?php echo e($product->lastPrice); ?>

										<span class="eur">Eur</span>
									</div>								
									<div class='btn'>
										<form action="<?php echo e(route('cartAdd')); ?>" method="POST">
										<?php echo csrf_field(); ?>
											<input type="hidden" name="qty" value='1'>
											<input type="hidden" name="product_id" value='<?php echo e($product->id); ?>'>
											<button class="btnAddToBasket btnAddProducts">
												<i class="fas fa-shopping-basket"></i>
												<p class="btnAddToBasketP">Dėti į Krepšelį</p>
											</button>
										</form>
										<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="btnProductMore btnProductInfo">
											<p class="btnProductInfoForward">Išsamiau apie prekę</p>
											<i class="fa-solid fa-angle-right"></i>
										</a>
									</div>
								</div>
						
								<?php else: ?>
								<div class="products">
										<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="productImg" ><img src="/images/products/<?php echo e($product->path); ?>"></a>
										<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="productText"><h3><?php echo e($product->name); ?></h3></a>
										<div class="productPrice"><?php echo e($product->lastPrice); ?>

											<span class="eur">Eur</span>
										</div>
										<div class='btn'>
											<form action="<?php echo e(route('cartAdd')); ?>" method="POST">
											<?php echo csrf_field(); ?>
												<input type="hidden" name="qty" value='1'>
												<input type="hidden" name="product_id" value='<?php echo e($product->id); ?>'>
												<button class="btnAddToBasket btnAddProducts">
													<i class="fas fa-shopping-basket"></i>
													<p class="btnAddToBasketP">Dėti į Krepšelį</p>
												</button>
											</form>
											<a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="btnProductMore btnProductInfo">
												<p class="btnProductInfoForward">Išsamiau apie prekę</p>
												<i class="fa-solid fa-angle-right"></i>
											</a>
										</div>
									
								</div>
							<?php endif; ?>
						<?php endif; ?>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div> <!-- productsWrapper -->
			
		</div> <!-- shopCateoryContainer -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageScript'); ?>

	<script src="<?php echo e(asset('js/products.js')); ?>"></script>
	<script>
	    document.addEventListener("DOMContentLoaded", function(event) { 
	        var scrollpos = localStorage.getItem('scrollpos');
	        if (scrollpos) window.scrollTo(0, scrollpos);
	    });

	    window.onbeforeunload = function(e) {
	        localStorage.setItem('scrollpos', window.scrollY);
	    };
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linvity\resources\views/front/products.blade.php ENDPATH**/ ?>