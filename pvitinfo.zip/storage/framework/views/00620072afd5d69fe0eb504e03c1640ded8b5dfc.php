

<?php $__env->startSection('name'); ?>

	Orders

<?php $__env->stopSection(); ?>	


<?php $__env->startSection('content'); ?>


<?php if(count($orders)>0): ?>

<div class="dropdown mb-3">
  <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Order By
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="">Date Ascending</a>
    <a class="dropdown-item" href="">Date Descending</a>
  </div>
</div>

	<table class="table table-hover col-9">

			<thead>
				<tr>
					<th>Order Number</th>
					<th>Date</th>
					<th></th>
					<th class="text-center">Status</th>
				</tr>
			</thead>
			<tbody>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($order->status == 1): ?>
				<tr>
					<td class="text-center"><?php echo e($order->order_number); ?></td>
					<td class=""><?php echo e($order->created_at); ?></td>
					<td class="">
						<a href="<?php echo e(route('orders.edit', $order->order_number)); ?>" type="button" class="btn btn-dark btn-sm">Info</a>
					</td>
					<td class="bg-success text-center">Completed</td>
				</tr>
			<?php elseif($order->status == 0): ?>
				<tr>
					<td class="align-middle text-center"><?php echo e($order->order_number); ?></td>
					<td><?php echo e($order->created_at); ?></td>
					<td>
						<a href="<?php echo e(route('orders.edit', $order->order_number)); ?>" type="button" class="btn btn-dark btn-sm">Info</a>
					</td>
					<td class="bg-danger text-center">Uncompleted</td>
				</tr>
			<?php endif; ?>
			</tbody>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>
 <?php else: ?> 

		<h1 class="text-center">No Order Yet</h1>

	

	<?php endif; ?>

		




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Linvity\resources\views/orders/index.blade.php ENDPATH**/ ?>