;

<?php $__env->startSection('name'); ?>

	Order Info

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($order->status == 0): ?>	
		<div class="d-flex justify-content-end"><h4 class="bg-danger">Uncompleted</h4></div>
		<?php break; ?>
	<?php elseif($order->status == 1): ?>
		<div class="d-flex justify-content-end"><h4 class="bg-success">Completed</h4></div>
		<?php break; ?>
	<?php endif; ?>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex mt-3 mb-5">
	<table class="table table-hover col-6">
		<thead>
			<tr>
				<th>Id</th>
				<th>Product Name</th>
				<th>Qty</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>					
					<td><?php echo e($order->product_id); ?></td>
					<td><?php echo e($order->products->name); ?></td>
					<td><?php echo e($order->product_qty); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</tbody>
	</table>
</div>	
	<h5>Shipping information</h5>
		<div class="mt-3 ml-5">	
			<p>Name: <?php echo e($order->name); ?></p>
			<p>Email: <?php echo e($order->email); ?></p>
			<p>Phone: <?php echo e($order->phone); ?></p>
			<p>Address: <?php echo e($order->address); ?></p>
			<p>Shipping: <?php echo e($order->deliveries->name); ?></p>
		</div>					

				
		<form action="<?php echo e(route('orders.update', $order->order_number)); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="_method" value="PATCH">
			<button class="btn btn-success" name="action" value="completed">Completed</button>
			<button class="btn btn-danger" name="action" value="uncompleted">Uncompleted</button>
		</form>
		

			

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Linvity\resources\views/orders/info.blade.php ENDPATH**/ ?>