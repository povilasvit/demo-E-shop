

<?php $__env->startSection('name'); ?>

	Other

<?php $__env->stopSection(); ?>	


<?php $__env->startSection('content'); ?>

<div class="col-6 p-2 bd-highlight">
	<ul class="list-group">	
		<?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="list-group-item d-flex bd-highlight">
				<div class="mr-auto p-2 bd-highlight"><?php echo e($other->name); ?></div>
				<div class="p-2 bd-highlight ml-4">
					<a href="<?php echo e(route('other.edit', $other->id)); ?>" type="button" class="btn btn-success btn-sm">Edit</a>
				</div>
				<div class="p-2 bd-highlight">
					<a href="" type="button" class="btn btn-info btn-sm">View</a>
				</div>
			</li>		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>


</div>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Linvity\resources\views/others/index.blade.php ENDPATH**/ ?>