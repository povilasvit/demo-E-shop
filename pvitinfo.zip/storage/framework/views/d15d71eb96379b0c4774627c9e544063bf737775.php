;

<?php $__env->startSection('name'); ?>

	Edit Product

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


	<div class="col-9 ml-5">
			<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="_method" value="PUT">
			<div class="form-group">
				<label for="category">Category</label>
				<select name="category_id" id="category_id" class="form-control col-6">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($category->id); ?>">
							<?php echo e($category->name); ?>

						</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label for="discount">Discount</label>
				<select name="discount_id" id="discount_id" class="form-control col-6">
					<?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($discount->id); ?>">
							<?php echo e($discount->name); ?>

						</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>


			<div class="form-group">
				<label for="name">Product Name</label>
				<input type="text" name="name" id="name" class="form-control col-6" value="<?php echo e($product->name); ?>">
			</div>
			<div class="form-group">
				<label for="inStock">Product in Stock</label>
				<input type="text" name="inStock" id="inStock" class="form-control col-6" value="<?php echo e($product->inStock); ?>">
			</div>
			<div class="form-group">
				<label for="name">Product Price</label>
				<input type="text" name="price" id="price" class="form-control col-6" value="<?php echo e($product->price); ?>">
			</div>
			<div class="form-group">
				<label for="description">Product Description</label>
				<textarea name="description" class="form-control" cols="5" rows="5"><?php echo e($product->description); ?></textarea>
			</div>
			<div class="form-group">
				<input id="content" type="hidden" name="content" value="<?php echo e($product->content); ?>">
				<trix-editor input="content"></trix-editor>
			</div>
			<div class="form-group">
				<label for="file">1st Photo</label><br>
				<img class="img-thumbnail mb-3" style="height: 45vh;" src="/images/products/<?php echo e($product->path); ?>"><br>
				<input type="file" name="file">
			</div>
			<div class="form-group">
				<label for="file">2nd Photo</label><br>
				<img class="img-thumbnail mb-3" style="height: 45vh;" src="/images/products/<?php echo e($product->path2); ?>"><br>
				<input type="file" name="file2">
			</div>
			<div class="form-group">
				<label for="file">3rd Photo</label><br>
				<img class="img-thumbnail mb-3" style="height: 45vh;" src="/images/products/<?php echo e($product->path3); ?>"><br>
				<input type="file" name="file3">
			</div>
			<div class="form-group">
				<button type="submit" class="form-control col-6 btn btn-info">Update Product</button>
			</div>

		</form>				



	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Linvity\resources\views/products/edit_product.blade.php ENDPATH**/ ?>